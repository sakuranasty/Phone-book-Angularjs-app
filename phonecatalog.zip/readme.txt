1. npm i
2. npm run copyfiles
3. npm run server
4. open localhost:8000