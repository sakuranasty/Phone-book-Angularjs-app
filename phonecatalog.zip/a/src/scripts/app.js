let contactBook = angular.module('ContactBook',[]);

function randomInteger(min,max){
    return Math.floor(min + Math.random()*(max+1-min));
};

function generateNumber(){
    let prefixRange = [300,400];
    let keyRange = [0,100];
    let indexRange = [0,100];
    return `${randomInteger(...prefixRange)}-${randomInteger(...keyRange)}-${randomInteger(...indexRange)}`;
};

contactBook.controller('MyListController', function($scope) {
    
    $scope.persons = [
        {'name': 'Julie', 'number': generateNumber()},
        {'name': 'Peter', 'number': generateNumber()},
        {'name': 'Stephen', 'number': generateNumber()},
        {'name': 'Hpsuh', 'number': generateNumber()},
        {'name': 'Daniele', 'number': generateNumber()},
        {'name': 'Elizabeth', 'number': generateNumber()},
        {'name': 'Cristine', 'number': generateNumber()}
    ];

});